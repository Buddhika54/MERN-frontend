import React from 'react';

const TeaVarieties = () => {
  return (
    <div>
      <h2>Tea Varieties</h2>
      <p>Tea varieties page coming soon...</p>
    </div>
  );
};

export default TeaVarieties;